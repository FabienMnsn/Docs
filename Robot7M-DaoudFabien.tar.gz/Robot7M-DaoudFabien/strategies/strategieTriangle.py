#strategie triangle equilateral

#imports

from robot_sim.utilitaires_geometrie import *

#code

class strategieTriangle():
    def __init__(self,robot):
        self.stop = False
        self.robot = robot
        self.cote = 1
        self.angle = 0
        self.en_rotation = False #determine si le robot doit tourner ou avancer

        self.angle_prec, x = self.robot.get_motor_position() #(left,right)

    def update(self):
        if self.stop == False:#securite au cas ou...
            #print("DEBUT DESSIN")
                            
            if self.cote == 1:
                #print("DEBUT DESSIN cote 1")
                #on 'dessine' le premier cote
                self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, 40)
                self.robot.set_motor_dps(self.robot.MOTOR_LEFT, 40)
                angle_actuel,y = self.robot.get_motor_position()#on avance tt droit pas besoin des 2 valeurs
                dist = ((angle_actuel - self.angle_prec)/360.0) * math.pi * (self.robot.WHEEL_DIAMETER/2.0) * 2
                #print(dist)
                if dist > 100: #en mm
                    #on a termine de parcourir les 10cm du cote on passe au suivant
                    self.cote += 1
                    self.angle_prec = angle_actuel
                    self.en_rotation = True
                    #print("FIN DESSIN cote 1")

            elif self.cote == 2:
                if self.en_rotation:
                    #print("___DEBUT ROTATION 2")
                    #on doit effectuer une rotation de 60deg
                    self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, -40)
                    self.robot.set_motor_dps(self.robot.MOTOR_LEFT, 40)
                    angle_actuel,y = self.robot.get_motor_position()
                    dist = ((angle_actuel - self.angle_prec)/360.0) * math.pi * (self.robot.WHEEL_DIAMETER/2.0) * 2
                    #print(dist)
                    if dist > self.robot.WHEEL_BASE_CIRCUMFERENCE /60:#un angle ddu triangle = 60deg
                        #si on entre ici on a fini deffectuer la rotation de 60deg on doit avancer
                        self.en_rotation = False
                        self.angle_prec = angle_actuel #on reset l'angle precedent avec celui de la position dont on part
                        #print("___FIN ROTATION 2")
                elif self.en_rotation == False:
                    #print("DEBUT DESSIN cote 2")
                    #on avance
                    self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, 40)
                    self.robot.set_motor_dps(self.robot.MOTOR_LEFT, 40)
                    angle_actuel,y = self.robot.get_motor_position()
                    dist = ((angle_actuel - self.angle_prec)/360.0) * math.pi * (self.robot.WHEEL_DIAMETER/2.0) * 2
                    #print(dist)
                    if dist > 100:
                        #on a termine de parcourir les 10cm du cote on passe au cote suivant
                        self.cote += 1
                        self.angle_prec = angle_actuel
                        self.en_rotation = True
                        #print("FIN DESSIN cote 2")
                        
            elif self.cote == 3:
                #on 'dessine' le troisieme cote
                if self.en_rotation:
                    #print("___DEBUT ROTATION 3")
                    #on doit effectuer une rotation de 60deg
                    self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, -40)
                    self.robot.set_motor_dps(self.robot.MOTOR_LEFT, 40)
                    angle_actuel,y = self.robot.get_motor_position()
                    dist = ((angle_actuel - self.angle_prec)/360.0) * math.pi * (self.robot.WHEEL_DIAMETER/2.0) * 2
                    if dist > self.robot.WHEEL_BASE_CIRCUMFERENCE /60:#un angle ddu triangle = 60deg
                        #si on entre ici on a fini deffectuer la rotation de 60deg on doit avancer
                        self.en_rotation = False
                        self.angle_prec = angle_actuel #on reset l'angle precedent avec celui de la position dont on part
                        #print("___FIN ROTATION 3")
                elif self.en_rotation == False:
                    #print("DEBUT DESSIN cote 3")
                    #on avance
                    self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, 40)
                    self.robot.set_motor_dps(self.robot.MOTOR_LEFT, 40)
                    angle_actuel,y = self.robot.get_motor_position()
                    dist = ((angle_actuel - self.angle_prec)/360.0) * math.pi * (self.robot.WHEEL_DIAMETER/2.0) * 2
                    if dist > 100:
                        #on a termine de parcourir les 10cm du cote on met fin a la strategie
                        self.stop = True
                        #print("FIN DESSIN cote 3")
        print(self.robot.safficher())#le modele marche pas ça sert a quoi d afficher les coords? => marche (peut etre) sur le gopygo...
                

