
#imports

from robot_gopy.robot2I013 import *
from images.detection_centre_carre import *


#code

class strategieSuivieBalise:
    def __init__(self, robot):
        self.robot = robot
        self.stop = False
        self.pas_de_temps = 0

    def update(self, distance):
        if pas_de_temps % 10 == 0:
            
            #alignement central de la tete du robot
            self.servo_rotate(90)
            #capture et traitement d'une image
            robot = Robot2I013()
            img = robot.get_image()
            img.save("capture.jpg")
            coords = detection_centre_carre("capture.jpg")

        #on considere que la capture fait 720*480 pixels comme la camera du robot
            #on determine dans quelle zeone de l'image les coords du centre du carre sont et on effectue l action en consequence
            if (coords[0] < 335):
                #le centre du carre detecte est a gauche du champs de vision du robot
                self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, -40)
                self.robot.set_motor_dps(self.robot.MOTOR_LEFT, 40)
                
            elif (coords[0] > 385):
                #le centre du carre detecte est a droite du champs de vision du robot
                self.robot.set_motor_dps(self.robot.MOTOR_RIGHT, 40)
                self.robot.set_motor_dps(self.robot.MOTOR_LEFT, -40)
                
            elif (coords[0] < 385 and coords[0] > 335):
                #carre + ou - au centre de l'image
                self.set_motor_dps(self.robot.MOTOR_LEFT + self.robot.MOTOR_RIGHT,180) # en Avant 
            pas_de_temps += 1
