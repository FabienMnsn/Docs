import robot_gopy.robot2I013

robot=robot2I013.Robot2I013()
robot.stop()
