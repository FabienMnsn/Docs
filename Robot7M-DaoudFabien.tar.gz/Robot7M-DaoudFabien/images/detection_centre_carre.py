#imports

from PIL import Image
import math
#code

def detection_centre_carre(img):
    """detecte le centre (ou presque dun carre vert present dans l image passee en parametre
    cette fonction ne marche que si lobjet recherche est un CARRE (cote = sqrt(surface)) de couleur vert
    ATTENTION: cette fct marche bin si le carre est entierement dans l image si il n y a qune partie visible => possibilite d erreur """
    image = Image.open(img)
    cpt = 0
    trouve_vert = False
    premier_pixel_vert = (0,0)
    for x in range(image.size[0]):
        for y in range(image.size[1]):
            pixel = image.getpixel((x,y))
            if trouve_vert == False and (pixel[0] < 128 and pixel[1] > 180 and pixel[2] <= 128):
                #image.putpixel((x,y),(255,0,255)) retour visuel en coloriant les pixels trouves
                cpt += 1
                trouve_vert = True
                premier_pixel_vert = (x,y)#angle haut gauche du carre
            if pixel[0] < 128 and pixel[1] > 180 and pixel[2] <= 128:
                #image.putpixel((x,y),(255,0,255))
                cpt += 1
    
    centre = (round(math.sqrt(cpt)/2+premier_pixel_vert[0]), round(math.sqrt(cpt)/2+premier_pixel_vert[1]))
    #print(centre)
    #image.putpixel((centre),(255,0,0))
    #image.show() #retour visuel de l'image inutile pour le robot
    return centre


#test rapide marche bien
if __name__ == '__main__':
    print(detection_centre_carre("solovert-1.jpg"))
        
