def distance_sensor():
    pass

class DistanceSensor:
    pass
