import robot2I013

robot=robot2I013.Robot2I013()
robot.stop()
robot.servo_rotate(90)
